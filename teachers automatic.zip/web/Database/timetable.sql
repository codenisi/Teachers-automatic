CREATE DATABASE IF NOT EXISTS `timetablegeneration` /*!40100 DEFAULT CHARACTER SET latin1 */;
USE `timetablegeneration`;


-- Dumping structure for table timetablegeneration.staff
CREATE TABLE IF NOT EXISTS `staff` (
  `StaffID` int(11) NOT NULL,
  `Name` varchar(50) NOT NULL,
  `Password` varchar(50) NOT NULL,
  `Gender` varchar(50) NOT NULL,
  `ContactNo` varchar(50) NOT NULL,
  `MailID` varchar(50) NOT NULL,
  `Address` varchar(50) NOT NULL,
  `Department` varchar(50) NOT NULL,
  PRIMARY KEY (`StaffID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table timetablegeneration.staff: ~3 rows (approximately)
/*!40000 ALTER TABLE `staff` DISABLE KEYS */;
INSERT INTO `staff` (`StaffID`, `Name`, `Password`, `Gender`, `ContactNo`, `MailID`, `Address`, `Department`) VALUES
	(subject1000, 'priya', 'priya', 'Female', '9876543210', 'venkatguy97@gmail.com', 'trichy', 'MCA'),
	(1001, 'raji', 'raji', 'Female', '9876543210', 'raji@gmail.com', 'trichy', 'MPHILL'),
	(1002, 'raja', 'raja', 'Male', '9876543210', 'raja@gmail.com', 'trichy', 'MPHILL');
/*!40000 ALTER TABLE `staff` ENABLE KEYS */;


-- Dumping structure for table timetablegeneration.subject
CREATE TABLE IF NOT EXISTS `subject` (
  `SubjectName` varchar(50) DEFAULT NULL,
  `Department` varchar(50) NOT NULL,
  `Semester` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table timetablegeneration.subject: ~4 rows (approximately)
/*!40000 ALTER TABLE `subject` DISABLE KEYS */;
INSERT INTO `subject` (`SubjectName`, `Department`, `Semester`) VALUES
	('Java', 'MCA', 'Sem 1'),
	('c++', 'MCA', 'Sem 1'),
	('python', 'MCA', 'Sem 1'),
	('SOM', 'MCA', 'Sem 1');
/*!40000 ALTER TABLE `subject` ENABLE KEYS */;


-- Dumping structure for table timetablegeneration.timetable
CREATE TABLE IF NOT EXISTS `timetable` (
  `Datee` varchar(50) NOT NULL,
  `Day` varchar(50) NOT NULL,
  `Department` varchar(50) NOT NULL,
  `Semester` varchar(50) NOT NULL,
  `Period` varchar(50) NOT NULL,
  `Subject` varchar(50) NOT NULL,
  `Staff` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- Dumping data for table timetablegeneration.timetable: ~6 rows (approximately)
/*!40000 ALTER TABLE `timetable` DISABLE KEYS */;
INSERT INTO `timetable` (`Datee`, `Day`, `Department`, `Semester`, `Period`, `Subject`, `Staff`) VALUES
	('11/11/21', 'Monday', 'MCA', 'Sem 1', 'Period 1', 'SOM', 'raja@gmail.com');
/*!40000 ALTER TABLE `timetable` ENABLE KEYS */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
